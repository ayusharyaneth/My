import Head from 'next/head';
import Hero from '../components/Hero';
import Projects from '../components/Projects';

export default function Home() {
  return (
    <div>
      <Head>
        <title>Futuristic Portfolio</title>
      </Head>
      <Hero />
      <Projects />
    </div>
  );
}