import { useRouter } from 'next/router';

export default function ProjectDetail() {
  const router = useRouter();
  const { id } = router.query;

  return (
    <div className='h-screen flex flex-col items-center justify-center bg-black text-white'>
      <h1 className='text-4xl font-bold'>Project {id} Details</h1>
      <p className='opacity-80 mt-4'>More information about project {id}.</p>
    </div>
  );
}