import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className='h-screen flex flex-col items-center justify-center bg-black text-white relative overflow-hidden'>
      {/* Background Animation */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1 }}
        className='absolute inset-0 bg-gradient-to-br from-blue-600 to-purple-800 opacity-30 rounded-full w-[120%] h-[120%]'
      ></motion.div>

      {/* Hero Text */}
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className='text-6xl font-bold relative z-10'
      >
        Welcome to My Portfolio
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 0.3 }}
        className='text-lg mt-4 opacity-80 relative z-10'
      >
        Showcasing Innovation & Web3 Excellence
      </motion.p>
    </section>
  );
}