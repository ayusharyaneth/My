import Link from 'next/link';
import { motion } from 'framer-motion';

const projects = [
  { id: 1, title: 'NFT Marketplace', description: 'A futuristic NFT platform', link: '/projects/1' },
  { id: 2, title: 'Decentralized Finance', description: 'A cutting-edge DeFi app', link: '/projects/2' },
  { id: 3, title: 'Metaverse Experience', description: 'An immersive virtual world', link: '/projects/3' }
];

export default function Projects() {
  return (
    <section className='py-20 bg-gray-900 text-white'>
      <h2 className='text-4xl text-center mb-10'>My Projects</h2>
      <div className='grid grid-cols-1 md:grid-cols-3 gap-6 px-10'>
        {projects.map((project) => (
          <Link key={project.id} href={project.link}>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className='bg-gray-800 p-6 rounded-lg shadow-lg cursor-pointer hover:bg-gray-700 transition'
            >
              <h3 className='text-2xl mb-2'>{project.title}</h3>
              <p className='opacity-80'>{project.description}</p>
            </motion.div>
          </Link>
        ))}
      </div>
    </section>
  );
}